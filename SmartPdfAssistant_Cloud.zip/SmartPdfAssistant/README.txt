نشر Smart PDF Assistant على الإنترنت (من غير Ollama ومن غير تثبيت عند المستخدمين)

1) احصل على مفتاح API (مجاني لـ Gemini): aistudio.google.com > Get API key.
2) أنشئ مستودع GitHub (يفضل Private) وارفع: app.py و requirements.txt و .gitignore
   (متبعتش ملف secrets الحقيقي ولا فولدر .venv).
3) ادخل share.streamlit.io > New app > اختار المستودع والملف app.py > Deploy.
4) من Settings > Secrets الصق محتوى .streamlit/secrets.toml.example بعد تعديل
   كلمة السر والمفتاح، واحفظ. التطبيق هيعيد التشغيل.
5) أرسل الرابط للمستخدمين مع كلمة السر. بيفتحوه من المتصفح فقط.

تشغيل محلي للتجربة:
   pip install -r requirements.txt
   حط المتغيرات: $env:GOOGLE_API_KEY="..." ; $env:APP_PASSWORD="123"
   streamlit run app.py
   (أو ارجع لـ Ollama: $env:LLM_PROVIDER="ollama" وثبّت langchain-ollama)
