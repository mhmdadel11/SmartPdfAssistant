import os
from typing import TypedDict

import streamlit as st
from pypdf import PdfReader
from langgraph.graph import StateGraph, START, END


# ---------------------------------
# 1. إعداد واجهة التطبيق
# ---------------------------------

st.set_page_config(page_title="Smart PDF Assistant", page_icon="🤖", layout="wide")


def get_secret(name, default=None):
    """يقرأ من Streamlit Secrets (على الاستضافة) أو من متغيرات البيئة (محلياً)."""
    try:
        return st.secrets[name]
    except Exception:
        return os.getenv(name, default)


# ---------------------------------
# 2. حماية بكلمة سر (اختياري لكن مهم لحماية رصيد الـ API)
# ---------------------------------

APP_PASSWORD = get_secret("APP_PASSWORD")

if APP_PASSWORD:
    if not st.session_state.get("authed"):
        st.title("🔒 Smart PDF Assistant")
        pwd = st.text_input("Password", type="password")
        if pwd:
            if pwd == str(APP_PASSWORD):
                st.session_state["authed"] = True
                st.rerun()
            else:
                st.error("Wrong password.")
        st.stop()

st.title("🤖 Smart PDF Assistant Agent")
st.write("Upload a PDF and let your AI Agent analyze it.")


# ---------------------------------
# 3. الاتصال بنموذج الذكاء الاصطناعي (قابل للتبديل من الـ Secrets)
# ---------------------------------

MAX_CHARS = int(get_secret("MAX_CHARS", 60000))   # أقصى عدد حروف يُرسل للنموذج
MAX_FILE_MB = int(get_secret("MAX_FILE_MB", 20))  # أقصى حجم ملف PDF


@st.cache_resource
def get_llm():
    provider = str(get_secret("LLM_PROVIDER", "gemini")).lower()
    model = get_secret("LLM_MODEL")

    if provider == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(
            model=model or "gemini-2.5-flash",
            google_api_key=get_secret("GOOGLE_API_KEY"),
            temperature=0,
        )
    if provider == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(
            model=model or "claude-sonnet-4-5",
            api_key=get_secret("ANTHROPIC_API_KEY"),
            temperature=0,
        )
    if provider == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(
            model=model or "gpt-4o-mini",
            api_key=get_secret("OPENAI_API_KEY"),
            temperature=0,
        )
    if provider == "ollama":  # للتشغيل المحلي فقط
        from langchain_ollama import ChatOllama
        return ChatOllama(model=model or "llama3.2", temperature=0)

    raise ValueError(f"Unknown LLM_PROVIDER: {provider}")


def ask_llm(prompt: str) -> str:
    response = get_llm().invoke(prompt)
    content = response.content
    if isinstance(content, list):  # بعض النماذج ترجع قائمة أجزاء
        return "".join(p if isinstance(p, str) else p.get("text", "") for p in content)
    return content


# ---------------------------------
# 4. تعريف بيانات الـ Agent
# ---------------------------------

class AgentState(TypedDict):
    task: str
    document_text: str
    question: str
    answer: str


# ---------------------------------
# 5. وظائف الـ Agent
# ---------------------------------

def summarize_node(state: AgentState):
    prompt = f"""
    Summarize the following document in Arabic.
    Organize the summary into clear sections.
    Mention the most important information.

    Document:
    {state["document_text"][:MAX_CHARS]}
    """
    return {"answer": ask_llm(prompt)}


def question_node(state: AgentState):
    prompt = f"""
    You are a PDF assistant.
    Answer the question using only the document.
    If the answer is not available, say so.
    Answer in Arabic.

    Document:
    {state["document_text"][:MAX_CHARS]}

    Question:
    {state["question"]}
    """
    return {"answer": ask_llm(prompt)}


def actions_node(state: AgentState):
    prompt = f"""
    Analyze this document and extract:
    1. Required actions.
    2. Recommendations.
    3. Important deadlines or dates, if mentioned.
    4. Responsible parties, if mentioned.

    Answer in Arabic.
    Do not invent information that is not in the document.

    Document:
    {state["document_text"][:MAX_CHARS]}
    """
    return {"answer": ask_llm(prompt)}


# ---------------------------------
# 6. بناء Agent باستخدام LangGraph
# ---------------------------------

def route_task(state: AgentState):
    return state["task"]


builder = StateGraph(AgentState)
builder.add_node("summarize", summarize_node)
builder.add_node("question", question_node)
builder.add_node("actions", actions_node)
builder.add_conditional_edges(
    START,
    route_task,
    {"summarize": "summarize", "question": "question", "actions": "actions"},
)
builder.add_edge("summarize", END)
builder.add_edge("question", END)
builder.add_edge("actions", END)
agent = builder.compile()


# ---------------------------------
# 7. رفع ملف PDF
# ---------------------------------

uploaded_file = st.file_uploader("Upload your PDF", type=["pdf"])

if uploaded_file is not None:

    if uploaded_file.size > MAX_FILE_MB * 1024 * 1024:
        st.error(f"File is larger than {MAX_FILE_MB} MB.")
        st.stop()

    pdf_reader = PdfReader(uploaded_file)

    extracted_text = ""
    for page_number, page in enumerate(pdf_reader.pages):
        page_text = page.extract_text() or ""
        extracted_text += f"\nPage {page_number + 1}:\n{page_text}"

    st.success("PDF uploaded successfully!")
    st.write(f"Number of pages: {len(pdf_reader.pages)}")

    if len(extracted_text) > MAX_CHARS:
        st.info(f"The document is long; only the first {MAX_CHARS:,} characters are analyzed.")

    # ---------------------------------
    # 8. اختيار المهمة
    # ---------------------------------

    st.subheader("Choose your task")

    task_labels = {
        "Summarize PDF": "summarize",
        "Ask a Question": "question",
        "Extract Action Items": "actions",
    }

    selected_task = st.selectbox("What would you like the Agent to do?", list(task_labels.keys()))

    question = ""
    if selected_task == "Ask a Question":
        question = st.text_input("Write your question:")

    # ---------------------------------
    # 9. تشغيل الـ Agent
    # ---------------------------------

    if st.button("Run AI Agent"):

        if not extracted_text.strip():
            st.warning("No readable text found in this PDF.")

        elif selected_task == "Ask a Question" and not question.strip():
            st.warning("Please enter your question.")

        else:
            initial_state = {
                "task": task_labels[selected_task],
                "document_text": extracted_text,
                "question": question,
                "answer": "",
            }

            try:
                with st.spinner("AI Agent is working..."):
                    result = agent.invoke(initial_state)

                st.subheader("AI Agent Result")
                st.markdown(result["answer"])

            except Exception as error:
                st.error(f"An error occurred: {error}")
